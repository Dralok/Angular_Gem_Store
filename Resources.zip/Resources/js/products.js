﻿
//(function () {
  
    var kb = kb || {};

    kb.storeProducts = angular.module('store-products', []);

    kb.storeProducts.directive('productGallery', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/product-gallery.html',
            controller: function () {
                this.current = 0;
                this.setCurrent = function (setCur) {
                    this.current = setCur || 0;
                };
            },
            controllerAs: 'gal'
        }
    });
    kb.storeProducts.directive('productTitle', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/product-title.html'
        };
    });
    kb.storeProducts.directive('productSpecs', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/product-specs.html'
        };
    });
    kb.storeProducts.directive('productDescription', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/product-description.html'
        };
    });
    kb.storeProducts.directive('productReviews', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/product-reviews.html'//,
            //controller: function () {
            //    this.review = {};

            //    this.addReview = function (product) {
            //        product.reviews.push(this.review);
            //        this.review = {};
            //    };
            //},
            //controllerAs: 'reviewCtrl'
        }
    });
    kb.storeProducts.directive('productPanels', function () {
        return {
            restrict: 'E',
            templateUrl: 'templates/product-panels.html',
            controller: function () {
                this.tab = 1;

                this.selectTab = function (setTab) {
                    this.tab = setTab;
                };
                this.isSelected = function (checkTab) {
                    return this.tab === checkTab;
                };
            },
            controllerAs: 'panel'
        };
    });

//});