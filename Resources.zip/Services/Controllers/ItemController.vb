﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports DotNetNuke.Web.Api

Public Class ItemController
    Inherits DnnApiController

    Private _inventoryRepository As InventoryRepository

    Public Sub New()
        _inventoryRepository = New InventoryRepository
    End Sub

    Protected Function OkResponse(Of T)(message As T) As HttpResponseMessage
        Return Request.CreateResponse(Of T)(HttpStatusCode.OK, message)
    End Function
    Protected Function ErrorResponse([error] As Exception) As HttpResponseMessage
        Return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, [error])
    End Function

    <HttpGet>
    <ActionName("test")>
    <AllowAnonymous>
    Public Function HelloWorld() As HttpResponseMessage
        Return OkResponse("Hello World!")
    End Function

    <HttpGet>
    <ValidateAntiForgeryToken>
    <ActionName("items")>
    <AllowAnonymous>
    Public Function GetInventory() As HttpResponseMessage
        Try
            Dim items = _inventoryRepository.GetItems
            Return OkResponse(items.ToList)
        Catch ex As Exception
            Return ErrorResponse(ex)
        End Try
    End Function
End Class
