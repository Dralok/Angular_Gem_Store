﻿Public Interface IImagePathModel

    Property RecordId As Integer
    Property ItemId As Integer
    Property ImagePath As String

End Interface
