﻿Public Interface IItemReviewModel
    Property RecordId As Integer
    Property ItemId As Integer
    Property Stars As Byte
    Property Body As String
    Property Author As String
    Property CreatedOn As Date

End Interface
