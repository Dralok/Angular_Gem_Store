﻿Imports DotNetNuke.Data

Public Class InventoryRepository

    Public Function GetItems() As IEnumerable(Of IItemModel)
        Using dtx = DataContext.Instance
            Dim rep = dtx.GetRepository(Of Item)
            Return rep.Get()
        End Using
    End Function


End Class
